Manifest-Version: 1.0
MIDlet-1: Checkpoint Fixture, , CheckpointMIDlet
MIDlet-Name: Checkpoint Fixture
MIDlet-Version: 1.0
MIDlet-Vendor: wfeature

